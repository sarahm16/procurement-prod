const roles = [
  {
    name: "Sourcer",
    description: "",
  },
  {
    name: "Account Manager",
    description: "",
  },
  {
    name: "Project Manager",
    description: "",
  },
  {
    name: "Sales Person",
    description: "",
  },
  {
    name: "Account Coordinator",
    description: "",
  },
];

async function seedRoles(prisma) {
  await prisma.roles.createMany({
    data: roles.map((role) => ({
      name: role.name,
      description: role.description,
    })),
  });
}

export default seedRoles;
