/**
 * GET /api/sourcing/sites/:siteId
 *
 * Every service line at one site, assigned or not, with the same seven checks
 * the sourcing grid shows — plus the backup vendors and full assignment
 * history per line.
 *
 * Register on the sourcing router alongside the others:
 *
 *   import { registerSiteSourcingRoute } from "./sourcingSiteRoute.js";
 *   ...
 *   registerSiteSourcingRoute(router, prisma, serializeGridRow);
 *   registerPricingRoutes(router, prisma, serializeGridRow);
 *   return router;
 *
 * `serializeGridRow` is passed in for the same reason the pricing routes take
 * it: the site profile merges rows returned by assign / replace / pricing
 * straight into the ones this endpoint returned, so a second shape here would
 * silently corrupt the cards.
 *
 * Why not reuse GET /api/sourcing?site_id=… : that route defaults to
 * state="todo" and paginates. A site profile wants every line including the
 * finished ones, never paged, and it wants the history — different enough that
 * bending the list route would make both harder to read.
 */

import { PrismaClientKnownRequestError } from "@prisma/client/runtime/library";

/**
 * The view carries ONE assignment per line: the primary (or the newest live
 * one if no primary is marked). A site profile wants the rest too:
 *   - backups:            other live vendors on the line, ready to step in
 *   - prior_assignments:  closed ones — "who did we have on snow last winter
 *                         and why did they go away", which is the reason
 *                         assignments get a status instead of getting deleted.
 */
async function assignmentsByContractSite(prisma, contractSiteIds) {
  const rows = await prisma.vendorContractSites.findMany({
    where: { contract_site_id: { in: contractSiteIds } },
    include: {
      Vendor: { select: { id: true, company: true } },
      VendorSiteStatus: { select: { id: true, name: true, category: true } },
      // The termination (or, later, end-of-service) notice behind a removal.
      Notice: { select: { id: true, notice_type: true, pandadoc_id: true } },
      // Warnings and compliance notices sent about this vendor on this line.
      Warnings: {
        select: {
          Warning: {
            select: {
              id: true,
              notice_type: true,
              date_sent: true,
              pandadoc_id: true,
              reason: true,
              status: true,
              penalty_amount: true,
            },
          },
        },
      },
    },
    orderBy: [{ is_primary: "desc" }, { created_at: "desc" }],
  });

  const map = new Map();
  for (const a of rows) {
    if (!map.has(a.contract_site_id)) map.set(a.contract_site_id, []);
    map.get(a.contract_site_id).push({
      assignment_id: a.id,
      vendor_id: a.vendor_id,
      vendor: a.Vendor?.company ?? null,
      is_primary: a.is_primary,
      status_id: a.status_id,
      status: a.VendorSiteStatus?.name ?? null,
      status_category: a.VendorSiteStatus?.category ?? null,
      created_at: a.created_at,
      // Set when they came off the line by notice (rather than replaced).
      removed_at: a.removed_at ?? null,
      removed_reason: a.removed_reason ?? null,
      removed_notes: a.removed_notes ?? null,
      notice_type: a.Notice?.notice_type ?? null,
      notice_url: a.Notice?.pandadoc_id
        ? `https://app.pandadoc.com/a/#/documents/${a.Notice.pandadoc_id}`
        : null,
      // Newest first. Voided warnings (sent in error) don't count.
      warnings: (a.Warnings ?? [])
        .map((w) => w.Warning)
        .filter((w) => w && w.status !== "voided")
        .sort((x, y) => new Date(y.date_sent) - new Date(x.date_sent))
        .map((w) => ({
          id: w.id,
          type: w.notice_type,
          penalty: w.penalty_amount == null ? null : Number(w.penalty_amount),
          date_sent: w.date_sent,
          complaint: w.reason,
          url: w.pandadoc_id ? `https://app.pandadoc.com/a/#/documents/${w.pandadoc_id}` : null,
        })),
    });
  }
  return map;
}

export function registerSiteSourcingRoute(router, prisma, serializeGridRow) {
  router.get("/sites/:siteId", async (req, res) => {
    const siteId = Number(req.params.siteId);
    if (!Number.isInteger(siteId)) {
      return res.status(400).json({ error: "Invalid site id" });
    }

    try {
      const rows = await prisma.sourcingGrid.findMany({
        where: { site_id: siteId },
        orderBy: [{ service_line: "asc" }],
      });

      // A site with no contract sites isn't an error — it just hasn't been set
      // up yet, and the tab has a perfectly good empty state for that.
      if (!rows.length) {
        return res.json({ site_id: siteId, rows: [], summary: emptySummary() });
      }

      const history = await assignmentsByContractSite(
        prisma,
        rows.map((r) => r.contract_site_id),
      );

      const serialized = rows.map((r) => {
        const base = serializeGridRow(r);
        const all = history.get(r.contract_site_id) ?? [];
        const others = all.filter(
          (a) => a.assignment_id !== base.assignment_id,
        );
        return {
          ...base,
          assignments: all,
          // Live vendors other than the one the view picked.
          backups: others.filter((a) => a.status_category !== "closed"),
          // Closed ones only. Rendered collapsed, so a line that's been
          // re-sourced three times doesn't bury the vendors working there now.
          prior_assignments: others.filter(
            (a) => a.status_category === "closed",
          ),
        };
      });

      res.json({
        site_id: siteId,
        rows: serialized,
        summary: summarize(serialized),
      });
    } catch (error) {
      if (error instanceof PrismaClientKnownRequestError) {
        console.error("Prisma error fetching site sourcing:", error);
        res.status(400).json({
          error: "Database Error",
          code: error.code,
          message: error.message,
        });
      } else {
        console.error("Error fetching site sourcing:", error);
        res.status(500).json({ error: "Internal Server Error" });
      }
    }
  });
}

const emptySummary = () => ({
  service_lines: 0,
  assigned: 0,
  sourced: 0,
  with_backup: 0,
  self_performed: 0,
  client_price_total: 0,
  vendor_price_total: 0,
});

/**
 * Header numbers. Computed server-side so the tab shows the same totals
 * whether or not every card has been expanded.
 */
function summarize(rows) {
  return rows.reduce(
    (acc, r) => ({
      service_lines: acc.service_lines + 1,
      assigned: acc.assigned + (r.vendor_id ? 1 : 0),
      sourced: acc.sourced + (r.is_sourced ? 1 : 0),
      with_backup: acc.with_backup + (r.backups.length ? 1 : 0),
      self_performed: acc.self_performed + (r.self_perform ? 1 : 0),
      client_price_total: acc.client_price_total + (r.client_price_total ?? 0),
      vendor_price_total: acc.vendor_price_total + (r.vendor_price_total ?? 0),
    }),
    emptySummary(),
  );
}

export default registerSiteSourcingRoute;
