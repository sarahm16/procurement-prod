import { Router } from "express";
import { PrismaClientKnownRequestError } from "@prisma/client/runtime/library";
import serializeNote from "../serializer/noteSerializer.js";
import serializeActivityLogEntry from "../serializer/activityLogSerializer.js";
import { logActivity } from "../utils/logActivity.js";
import makeContactRoutes from "./makeContactRoutes.js";
import serializeContact from "../serializer/serializeContact.js";

import multer from "multer";
import { uploadToBlob } from "../services/blob/uploadToBlob.js";

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 25 * 1024 * 1024 },
});

const SITE_ATTACHMENTS_CONTAINER = "site-attachments"; // or reuse a shared container

const entity_type_id = 2; // Site entity type

// ─── Sourcing ────────────────────────────────────────────────────────────────

// Prisma returns Decimal instances, which JSON-stringify to strings. Convert
// for the client so it isn't doing arithmetic on "1250.0000".
const toNumber = (v) => (v == null ? null : Number(v));

const serializeAssignmentPricing = (p) => {
  const vendor_price = toNumber(p.vendor_price);
  const client_price = toNumber(p.ContractSiteServices?.client_price);
  return {
    id: p.id,
    contract_site_service_id: p.contract_site_service_id,
    vendor_price,
    client_price,
    margin:
      vendor_price != null && client_price != null
        ? Number((client_price - vendor_price).toFixed(4))
        : null,
    created_at: p.created_at,
  };
};

// One row of the sourcing tab: a vendor assigned to a contract site.
// `id` is the VendorContractSites id — the handle every mutation uses.
const serializeVendorAssignment = (vcs) => {
  const pricing = (vcs.ServicePricing ?? []).map(serializeAssignmentPricing);
  return {
    id: vcs.id,
    is_primary: vcs.is_primary,
    created_at: vcs.created_at,

    // assignment status (VendorSiteStatuses)
    status_id: vcs.status_id ?? null,
    status: vcs.VendorSiteStatus?.name ?? null,
    status_category: vcs.VendorSiteStatus?.category ?? null,

    // vendor
    vendor_id: vcs.Vendor?.id ?? null,
    company: vcs.Vendor?.company ?? null,
    contact_name: vcs.Vendor?.contact_name ?? null,
    contact_email: vcs.Vendor?.contact_email ?? null,
    contact_phone: vcs.Vendor?.contact_phone ?? null,
    lat: toNumber(vcs.Vendor?.lat),
    lng: toNumber(vcs.Vendor?.lng),

    // company-level status — the eligibility gate, distinct from `status` above
    vendor_status: vcs.Vendor?.VendorStatus?.name ?? null,
    vendor_status_color: vcs.Vendor?.VendorStatus?.color ?? null,

    trades: (vcs.Vendor?.VendorTrades ?? [])
      .map((vt) => vt.Trade?.name)
      .filter(Boolean),

    pricing,
    priced_service_count: pricing.length,
  };
};

const serializeSiteSourcing = (contractSites) =>
  (contractSites ?? []).map((cs) => {
    const vendors = (cs.VendorContractSites ?? []).map(
      serializeVendorAssignment,
    );
    return {
      contract_site_id: cs.id,
      service_line: cs.Contract?.ServiceLine?.name ?? null,
      service_line_id: cs.Contract?.ServiceLine?.id ?? null,
      status: cs.Status?.name ?? null,
      status_color: cs.Status?.color ?? null,
      service_count: cs._count?.ContractSiteServices ?? 0,
      vendors,
      vendor_count: vendors.length,
    };
  });

/**
 * Shared `include` for the ContractSites relation.
 *
 * The list and detail endpoints MUST select the same fields, because both feed
 * `serializeServiceLines`, which reads cs.id, cs.status_id and cs.Status. When
 * the list query omitted them, every service-line chip on the sites grid came
 * back with contract_site_id: undefined and a null status/colour.
 */
const CONTRACT_SITES_SELECT = {
  id: true,
  status_id: true,
  Status: true,
  Contract: {
    select: {
      ServiceLine: {
        select: {
          id: true,
          name: true,
        },
      },
    },
  },
};

const serializeAttachment = (a) => ({
  id: a.id,
  file_name: a.file_name,
  blob_url: a.blob_url,
  content_type: a.content_type,
  created_at: a.created_at,
  uploaded_by: a.uploaded_by,
});

// Always returns a plain string (or null) — never a Prisma object, so the
// client can render it directly.
const serializeClient = (client) => client?.client ?? null;

// Always returns an array of flat objects with primitive values.
const serializeServiceLines = (contractSites) =>
  (contractSites ?? []).map((cs) => ({
    contract_site_id: cs.id ?? null,
    service_line: cs.Contract?.ServiceLine?.name ?? null,
    service_line_id: cs.Contract?.ServiceLine?.id ?? null,
    status_id: cs.status_id ?? null, // ← for marking current in the menu
    status: cs.Status?.name ?? null,
    status_color: cs.Status?.color ?? null,
  }));

const serializeSiteById = (site, notes, activityLog) => ({
  ...site,
  service_lines: serializeServiceLines(site.ContractSites),
  client: serializeClient(site.Client),
  notes: (notes ?? []).map(serializeNote),
  activity_log: (activityLog ?? []).map(serializeActivityLogEntry),
  contacts: (site.Contacts ?? []).map(serializeContact),
  attachments: (site.Attachments ?? []).map(serializeAttachment),
  // NOTE: this is the full status OBJECT ({ id, name, color, ... }), not a
  // string. Anything on the site profile that renders it must read
  // `site.status.name` — rendering `site.status` directly will throw
  // "Objects are not valid as a React child".
  status: site?.Status ?? null,
  status_name: site?.Status?.name ?? null,
  status_color: site?.Status?.color ?? null,
});

const serializeSite = (site) => ({
  ...site,
  service_lines: serializeServiceLines(site.ContractSites),
  client: serializeClient(site.Client),
  status: site?.Status ?? null,
  status_name: site?.Status?.name ?? null,
  status_color: site?.Status?.color ?? null,
});

// Treat null / undefined / "" as the same, and trim strings so Char(50)
// padding (mailing_state!) doesn't register as a change.
const norm = (v) => {
  if (v === null || v === undefined) return "";
  return typeof v === "string" ? v.trim() : v;
};

export default function sitesRouter(prisma) {
  const router = Router();

  // GET /api/sites
  router.get("/", async (req, res) => {
    try {
      const sites = await prisma.Sites.findMany({
        include: {
          Client: {
            select: {
              id: true,
              client: true,
            },
          },
          ContractSites: {
            select: CONTRACT_SITES_SELECT,
          },
          Status: true,
        },
      });
      res.json(sites.map(serializeSite));
    } catch (error) {
      if (error instanceof PrismaClientKnownRequestError) {
        console.error("Prisma error fetching sites:", error);
        res.status(400).json({
          error: "Database Error",
          code: error.code,
          message: error.message,
        });
      } else {
        console.error("Error fetching sites:", error);
        res.status(500).json({ error: "Internal Server Error" });
      }
    }
  });

  router.get("/statuses", async (req, res) => {
    try {
      const statuses = await prisma.siteStatuses.findMany();
      res.json(statuses);
    } catch (error) {
      if (error instanceof PrismaClientKnownRequestError) {
        console.error("Prisma error fetching statuses:", error);
        res.status(400).json({
          error: "Database Error",
          code: error.code,
          message: error.message,
        });
      } else {
        console.error("Error fetching workorder statuses:", error);
        res.status(500).json({ error: "Internal Server Error" });
      }
    }
  });

  // GET /api/sites/:id/sourcing
  router.get("/:id/sourcing", async (req, res) => {
    const { id } = req.params;
    try {
      const contractSites = await prisma.contractSites.findMany({
        where: { site_id: Number(id) },
        select: {
          id: true,
          Status: true,
          _count: { select: { ContractSiteServices: true } },
          Contract: {
            select: { ServiceLine: { select: { id: true, name: true } } },
          },
          VendorContractSites: {
            select: {
              id: true,
              is_primary: true,
              status_id: true,
              created_at: true,
              VendorSiteStatus: {
                select: { id: true, name: true, category: true },
              },
              Vendor: {
                select: {
                  id: true,
                  company: true,
                  lat: true,
                  lng: true,
                  contact_name: true,
                  contact_email: true,
                  contact_phone: true,
                  VendorStatus: {
                    select: { id: true, name: true, color: true },
                  },
                  VendorTrades: {
                    select: { Trade: { select: { id: true, name: true } } },
                  },
                },
              },
              ServicePricing: {
                select: {
                  id: true,
                  vendor_price: true,
                  contract_site_service_id: true,
                  created_at: true,
                  ContractSiteServices: {
                    select: { id: true, client_price: true },
                  },
                },
              },
            },
            orderBy: [{ is_primary: "desc" }, { created_at: "asc" }],
          },
        },
        orderBy: { id: "asc" },
      });

      res.json(serializeSiteSourcing(contractSites));
    } catch (error) {
      if (error instanceof PrismaClientKnownRequestError) {
        console.error("Prisma error fetching site sourcing:", error);
        res.status(400).json({
          error: "Database Error",
          code: error.code,
          message: error.message,
        });
      } else {
        console.error("Error fetching site sourcing:", error);
        res.status(500).json({ error: "Internal Server Error" });
      }
    }
  });

  // GET /api/sites/:id
  router.get("/:id", async (req, res) => {
    const { id } = req.params;
    try {
      const [site, notes, activityLog] = await Promise.all([
        prisma.Sites.findUnique({
          where: { id: Number(id) },
          include: {
            Client: {
              select: {
                id: true,
                client: true,
              },
            },
            ContractSites: {
              select: CONTRACT_SITES_SELECT,
            },
            Contacts: {
              include: {
                ContactRole: true,
              },
            },
            Status: true,
          },
        }),
        prisma.notes.findMany({
          where: {
            entity_type_id: entity_type_id, // Site entity type
            entity_id: Number(id),
            parent_note_id: null,
          },
          include: {
            Author: true,
            Replies: {
              include: { Author: true },
            },
            NoteTaggedUsers: {
              include: { TaggedUser: true },
            },
          },
        }),
        prisma.activityLog.findMany({
          where: {
            entity_type_id: entity_type_id, // Site entity type
            entity_id: Number(id),
          },
          include: {
            Employee: true,
          },
        }),
      ]);

      // Without this, a bad id spread `null` and then threw on site.Contacts.
      if (!site) {
        return res.status(404).json({ error: "Site not found" });
      }

      res.json(serializeSiteById(site, notes, activityLog));
    } catch (error) {
      if (error instanceof PrismaClientKnownRequestError) {
        console.error("Prisma error fetching site:", error);
        res.status(400).json({
          error: "Database Error",
          code: error.code,
          message: error.message,
        });
      } else {
        console.error("Error fetching site:", error);
        res.status(500).json({ error: "Internal Server Error" });
      }
    }
  });

  // POST /api/sites
  router.post("/", async (req, res) => {
    try {
      // The create must include the same relations the serializer reads,
      // otherwise serializeSite receives a bare row and blows up.
      const site = await prisma.Sites.create({
        data: req.body,
        include: {
          Client: {
            select: {
              id: true,
              client: true,
            },
          },
          ContractSites: {
            select: CONTRACT_SITES_SELECT,
          },
          Status: true,
        },
      });
      res.status(201).json(serializeSite(site));
    } catch (error) {
      if (error instanceof PrismaClientKnownRequestError) {
        console.error("Prisma error creating site:", error);
        res.status(400).json({
          error: "Database Error",
          code: error.code,
          message: error.message,
        });
      } else {
        console.error("Error creating site:", error);
        res.status(500).json({ error: "Internal Server Error" });
      }
    }
  });

  // GET /api/sites/:id/attachments
  router.get("/:id/attachments", async (req, res) => {
    const { id } = req.params;
    try {
      const attachments = await prisma.siteAttachments.findMany({
        where: { site_id: Number(id) },
        orderBy: { created_at: "desc" },
      });
      res.json(attachments.map(serializeAttachment));
    } catch (error) {
      console.error("Error fetching site attachments:", error);
      res.status(500).json({ error: "Failed to fetch attachments" });
    }
  });

  // POST /api/sites/:id/attachments  (multipart: files[], user_id)
  router.post("/:id/attachments", upload.array("files"), async (req, res) => {
    const { id } = req.params;
    const { user_id } = req.body;

    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ error: "No files provided" });
    }

    try {
      const created = [];
      for (const file of req.files) {
        const safeName = file.originalname.replace(/[^\w.\-]/g, "_");
        const blobPath = `sites/${id}/${Date.now()}-${safeName}`;

        const blobUrl = await uploadToBlob(
          SITE_ATTACHMENTS_CONTAINER,
          file.buffer,
          blobPath,
          file.mimetype,
        );

        const record = await prisma.siteAttachments.create({
          data: {
            site_id: Number(id),
            blob_url: blobUrl,
            file_name: file.originalname,
            content_type: file.mimetype,
            uploaded_by: user_id ? Number(user_id) : null,
            category: "",
          },
        });
        created.push(record);
      }

      await logActivity(prisma, {
        entityTypeId: entity_type_id,
        entityId: Number(id),
        fieldChanged: "attachment",
        previousValue: null,
        newValue: `Uploaded ${created.length} file(s)`,
        changedBy: user_id ? Number(user_id) : null,
        action: "CREATE",
      });

      res.status(201).json(created.map(serializeAttachment));
    } catch (error) {
      console.error("Error uploading site attachments:", error);
      res.status(500).json({ error: "Failed to upload attachments" });
    }
  });

  // DELETE /api/sites/:id/attachments/:attachmentId
  router.delete("/:id/attachments/:attachmentId", async (req, res) => {
    const { attachmentId } = req.params;
    try {
      await prisma.siteAttachments.delete({
        where: { id: Number(attachmentId) },
      });
      res.status(204).end();
    } catch (error) {
      console.error("Error deleting site attachment:", error);
      res.status(500).json({ error: "Failed to delete attachment" });
    }
  });

  // PUT /api/sites/:id/status
  router.put("/:id/status", async (req, res) => {
    const { id } = req.params;
    const { status_id, user_id } = req.body;

    if (status_id == null) {
      return res.status(400).json({ error: "status_id is required" });
    }

    try {
      const updated = await prisma.$transaction(async (tx) => {
        // fetch the current status first, for the activity log's previous value
        const current = await tx.Sites.findUnique({
          where: { id: Number(id) },
          include: { Status: true },
        });

        const site = await tx.Sites.update({
          where: { id: Number(id) },
          data: { status_id: Number(status_id) },
          include: { Status: true },
        });

        await logActivity(tx, {
          entityTypeId: entity_type_id,
          entityId: Number(id),
          fieldChanged: "status",
          previousValue: current?.Status?.name ?? null,
          newValue: site.Status?.name ?? null,
          changedBy: user_id ?? null,
          action: "UPDATE",
        });

        return site;
      });

      res.json({
        status: updated.Status ?? null,
        status_id: updated.status_id,
        status_name: updated.Status?.name ?? null,
        status_color: updated.Status?.color ?? null,
      });
    } catch (error) {
      if (error instanceof PrismaClientKnownRequestError) {
        console.error("Prisma error updating site status:", error);
        res.status(400).json({
          error: "Database Error",
          code: error.code,
          message: error.message,
        });
      } else {
        console.error("Error updating site status:", error);
        res.status(500).json({ error: "Internal Server Error" });
      }
    }
  });

  // PUT /api/sites/:id/contract-sites/:contractSiteId/status
  router.put("/:id/contract-sites/:contractSiteId/status", async (req, res) => {
    const { id, contractSiteId } = req.params;
    const { status_id, user_id } = req.body;

    if (status_id == null) {
      return res.status(400).json({ error: "status_id is required" });
    }

    try {
      const updated = await prisma.$transaction(async (tx) => {
        // current status (for the activity log's previous value)
        const current = await tx.contractSites.findUnique({
          where: { id: Number(contractSiteId) },
          include: {
            Status: true,
            Contract: { include: { ServiceLine: true } },
          },
        });

        const contractSite = await tx.contractSites.update({
          where: { id: Number(contractSiteId) },
          data: { status_id: Number(status_id) },
          include: {
            Status: true,
            Contract: { include: { ServiceLine: true } },
          },
        });

        // log against the SITE, so it shows in the site's activity feed
        const serviceLineName =
          contractSite.Contract?.ServiceLine?.name ?? "service line";
        await logActivity(tx, {
          entityTypeId: entity_type_id, // 2 = Site
          entityId: Number(id),
          fieldChanged: "service_line_status",
          previousValue: current?.Status?.name ?? null,
          newValue: `${serviceLineName}: ${contractSite.Status?.name ?? ""}`,
          changedBy: user_id ?? null,
          action: "UPDATE",
        });

        return contractSite;
      });

      // Matches one element of `service_lines` so the card can patch local
      // state without a refetch.
      res.json({
        contract_site_id: updated.id,
        service_line: updated.Contract?.ServiceLine?.name ?? null,
        service_line_id: updated.Contract?.ServiceLine?.id ?? null,
        status_id: updated.status_id,
        status: updated.Status?.name ?? null,
        status_color: updated.Status?.color ?? null,
      });
    } catch (error) {
      if (error instanceof PrismaClientKnownRequestError) {
        console.error("Prisma error updating contract site status:", error);
        res.status(400).json({
          error: "Database Error",
          code: error.code,
          message: error.message,
        });
      } else {
        console.error("Error updating contract site status:", error);
        res.status(500).json({ error: "Internal Server Error" });
      }
    }
  });

  router.use(
    makeContactRoutes({
      delegate: "siteContacts",
      foreignKey: "site_id",
      entityTypeId: 2,
    }),
  );

  return router;
}
